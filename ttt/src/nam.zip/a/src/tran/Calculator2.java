package tran;

public class Calculator2 {
    public int number1;
    public int number2;
    public int result;

    public void sub() {
        result = number1 - number2;
    }
}
