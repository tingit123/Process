package tran;

public class Calculator3 {
    private int number1;
    private int number2;

    public Calculator3(int number1, int number2) {
        super();
        this.number1 = number1;
        this.number2 = number2;
    }

    public int mul() {
        return number1 * number2;
    }
}
