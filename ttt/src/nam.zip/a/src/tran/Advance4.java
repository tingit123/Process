package tran;

public class Advance4 {
    /**
     * Kiểm tra số nguyên tố
     * @param n: số nguyên dương
     * @return: true là số nguyên tố, false không phải là số nguyên tố
     */
    public boolean isPrimeNumber(int n) {
        // số nguyên n < 2 không phải là số nguyên tố
        if (n < 2) {
            return false;
        }
        // kiểm tra số nguyên tố khi n >= 2
        int squareRoot = (int) Math.sqrt(n);
        for (int i = 2; i <= squareRoot; i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}
