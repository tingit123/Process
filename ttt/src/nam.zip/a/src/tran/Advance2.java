package tran;

public class Advance2 {
    public int sum(long number) {
        int sum = 0;
        number = Math.abs(number); // xử lý số âm
        while (number != 0) {
            sum += number % 10;
            number /= 10;
        }
        return sum;
    }
}
