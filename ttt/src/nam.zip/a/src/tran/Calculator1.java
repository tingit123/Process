package tran;

public class Calculator1 {
public int add(int number1, int number2) {
return number1 + number2;
}
}

