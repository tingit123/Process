package tran;

/**
 * Kiểm tra một số có đối xứng hay không
 * Nếu đối xứng trả về true, ngược lại trả về false
 * VD: 112 -> false, 12121 -> true
 */
public class Advance5 {
    public boolean kiemTraDoiXung(int number) {
        String str = number + "";
        String reversed = new StringBuilder(str).reverse().toString();
        return str.equals(reversed);
    }
}
