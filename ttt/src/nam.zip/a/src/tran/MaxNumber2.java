package tran;

public class MaxNumber2 {
    public static int max2(int number1, int number2) {
        if (number1 > number2)
            return number1;
        else
            return number2;
    }
}
