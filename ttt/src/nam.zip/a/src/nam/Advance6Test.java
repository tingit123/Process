package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.Advance6;

public class Advance6Test {

    Advance6 adv = new Advance6();

    @Test
    void testTinhTuoiHopLe() {
        // Các trường hợp sinh nhật hợp lệ
        assertEquals(21, adv.tinhTuoi(12, 1, 1999)); // Ngày sinh hợp lệ: 12/1/1999
        assertEquals(20, adv.tinhTuoi(12, 5, 1999)); // Ngày sinh hợp lệ: 12/5/1999
    }

    @Test
    void testTinhTuoiSaiDinhDang() {
        // Trường hợp nhập ngày không hợp lệ (tháng 13)
        assertEquals(-1, adv.tinhTuoi(12, 13, 1999)); // Tháng 13 không hợp lệ

        // Trường hợp nhập ngày không hợp lệ (ngày 32)
        assertEquals(-1, adv.tinhTuoi(32, 1, 1999));  // Ngày 32 không hợp lệ

        // Trường hợp nhập năm không hợp lệ
        assertEquals(-1, adv.tinhTuoi(12, 1, 2023)); // Số tuổi sẽ sai nếu nhập năm tương lai
    }

    @Test
    void testTinhTuoiNgaySinhMai() {
        // Trường hợp tuổi chưa đến (ngày sinh trong năm hiện tại)
        assertEquals(0, adv.tinhTuoi(1, 1, 2022)); // Sinh ngày 1/1/2022, tuổi sẽ là 0
    }

    @Test
    void testNgaySinhTrongQuaKhu() {
        // Trường hợp tuổi là một số lớn (sinh từ lâu)
        assertEquals(100, adv.tinhTuoi(12, 5, 1923)); // Sinh ngày 12/5/1923
    }
}
