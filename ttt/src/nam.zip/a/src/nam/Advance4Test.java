package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.Advance4;

public class Advance4Test {

    Advance4 adv = new Advance4();

    @Test
    void testSoNguyenTo() {
        // Kiểm tra các số nguyên tố nhỏ
        assertTrue(adv.isPrimeNumber(2)); // 2 là số nguyên tố
        assertTrue(adv.isPrimeNumber(3)); // 3 là số nguyên tố
        assertTrue(adv.isPrimeNumber(5)); // 5 là số nguyên tố
        assertTrue(adv.isPrimeNumber(7)); // 7 là số nguyên tố
    }

    @Test
    void testKhongPhaiSoNguyenTo() {
        // Kiểm tra các số không phải là số nguyên tố
        assertFalse(adv.isPrimeNumber(1));  // 1 không phải là số nguyên tố
        assertFalse(adv.isPrimeNumber(4));  // 4 không phải là số nguyên tố
        assertFalse(adv.isPrimeNumber(9));  // 9 không phải là số nguyên tố
        assertFalse(adv.isPrimeNumber(15)); // 15 không phải là số nguyên tố
    }

    @Test
    void testSoAm() {
        // Kiểm tra các số âm (các số âm không phải là số nguyên tố)
        assertFalse(adv.isPrimeNumber(-1)); // Số âm không phải là số nguyên tố
        assertFalse(adv.isPrimeNumber(-10)); // Số âm không phải là số nguyên tố
    }

    @Test
    void testSo0() {
        // Kiểm tra số 0
        assertFalse(adv.isPrimeNumber(0)); // 0 không phải là số nguyên tố
    }

    @Test
    void testSoNguyenToLon() {
        // Kiểm tra các số nguyên tố lớn
        assertTrue(adv.isPrimeNumber(97));  // 97 là số nguyên tố
        assertTrue(adv.isPrimeNumber(101)); // 101 là số nguyên tố
        assertTrue(adv.isPrimeNumber(103)); // 103 là số nguyên tố
    }
}
