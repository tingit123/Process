package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.Advance5;

public class Advance5Test {

    Advance5 adv = new Advance5();

    @Test
    void testSoDoiXung() {
        // Palindrome > true
        assertTrue(adv.kiemTraDoiXung(12121));
        assertTrue(adv.kiemTraDoiXung(5));    // single digit
        assertTrue(adv.kiemTraDoiXung(0));    // zero
    }

    @Test
    void testKhongDoiXung() {
        // Non-palindrome > false
        assertFalse(adv.kiemTraDoiXung(112));
        assertFalse(adv.kiemTraDoiXung(10));   // ends with zero
    }

    @Test
    void testSoAm() {
        // Negative numbers are not considered palindrome here
        assertFalse(adv.kiemTraDoiXung(-121));
        assertFalse(adv.kiemTraDoiXung(-1));
    }
}
