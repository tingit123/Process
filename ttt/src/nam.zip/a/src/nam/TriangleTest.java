package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.Triangle;

public class TriangleTest {

    @Test
    void testCanhThuNhatLonNhat() {
        Triangle triangle = new Triangle(10, 6, 4);
        int result = triangle.maxLength();
        assertEquals(10, result);
    }

    @Test
    void testCanhThuHaiLonNhat() {
        Triangle triangle = new Triangle(5, 11, 7);
        int result = triangle.maxLength();
        assertEquals(11, result);
    }

    @Test
    void testCanhThuBaLonNhat() {
        Triangle triangle = new Triangle(3, 8, 12);
        int result = triangle.maxLength();
        assertEquals(12, result);
    }
}
