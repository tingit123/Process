package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.Calculator2;

public class Calculator2Test {

    @Test
    void testPhepTruBinhThuong() {
        Calculator2 calc = new Calculator2();
        calc.number1 = 20;
        calc.number2 = 5;
        calc.sub();
        assertEquals(15, calc.result); 
    }

    @Test
    void testTranSoNguyenDuong() {
        Calculator2 calc = new Calculator2();
        calc.number1 = Integer.MAX_VALUE;
        calc.number2 = -1;
        calc.sub();
        assertTrue(calc.result < 0, "Ket qua bi tran nen gia tri thanh so am");
    }

    @Test
    void testTranSoNguyenAm() {
        Calculator2 calc = new Calculator2();
        calc.number1 = Integer.MIN_VALUE;
        calc.number2 = 1;
        calc.sub();
        assertTrue(calc.result > 0, "Ket qua bi tran nen gia tri thanh so duong");
    }
}
