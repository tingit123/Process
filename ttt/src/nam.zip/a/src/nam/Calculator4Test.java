package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.Calculator4;

public class Calculator4Test {

    @Test
    void testPhepChiaBinhThuong() {
        Calculator4 calc = new Calculator4();
        calc.setNumber1(10);
        calc.setNumber2(2);
        int ketqua = calc.div(); // 10 / 2 = 5
        assertEquals(5, ketqua);
    }

    @Test
    void testChiaChoKhong() {
        Calculator4 calc = new Calculator4();
        calc.setNumber1(10);
        calc.setNumber2(0);
        assertThrows(ArithmeticException.class, () -> {
            calc.div(); // 10 / 0 → lỗi chia cho 0
        }, "Chia cho 0 phai nem ra ArithmeticException");
    }

    @Test
    void testChiaTraVeSoThuc() {
        Calculator4 calc = new Calculator4();
        calc.setNumber1(5);
        calc.setNumber2(2);
        float ketqua = (float) calc.getNumber1() / calc.getNumber2(); // ép kiểu để có kết quả 2.5
        assertEquals(2.5f, ketqua, 0.0001f);
    }
}
