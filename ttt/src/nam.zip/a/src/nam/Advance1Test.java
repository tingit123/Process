package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.Advance1;

public class Advance1Test {

    Advance1 adv = new Advance1();

    @Test
    void testSoDuongKhacNhau() {
        assertEquals(6, adv.USCLN(54, 24));
        assertEquals(216, adv.BSCNN(54, 24));
    }

    @Test
    void testHaiSoBangNhau() {
        assertEquals(25, adv.USCLN(25, 25));
        assertEquals(25, adv.BSCNN(25, 25));
    }

    @Test
    void testHaiSoNguyenToCungNhau() {
        assertEquals(1, adv.USCLN(9, 28));
        assertEquals(252, adv.BSCNN(9, 28));
    }

    @Test
    void testMotSoBang0() {
        assertEquals(5, adv.USCLN(0, 5));
        assertEquals(0, adv.BSCNN(0, 5));
    }

    @Test
    void testHaiSoBang0() {
        // Có thể ném ngoại lệ, tùy cách xử lý
        Exception exception = assertThrows(ArithmeticException.class, () -> {
            adv.BSCNN(0, 0);
        });
        assertTrue(exception.getMessage().contains("/ by zero"));
    }

    @Test
    void testSoAmVaSoDuong() {
        assertEquals(4, adv.USCLN(-12, 8));
        assertEquals(24, adv.BSCNN(-12, 8));
    }

    @Test
    void testHaiSoAm() {
        assertEquals(3, adv.USCLN(-9, -6));
        assertEquals(18, adv.BSCNN(-9, -6));
    }
}
