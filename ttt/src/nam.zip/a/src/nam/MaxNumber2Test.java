package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.MaxNumber2;

public class MaxNumber2Test {

    @Test
    void testSoThuNhatLonHon() {
        int ketqua = MaxNumber2.max2(10, 5);
        assertEquals(10, ketqua);
    }

    @Test
    void testSoThuHaiLonHon() {
        int ketqua = MaxNumber2.max2(3, 7);
        assertEquals(7, ketqua);
    }
}
