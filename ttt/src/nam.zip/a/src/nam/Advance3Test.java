package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.Advance3;

public class Advance3Test {

    Advance3 adv = new Advance3();

    @Test
    void testFibonacciAm() {
        // Case n < 0 → trả về -1
        assertEquals(-1, adv.fibonacci(-5));
        assertEquals(-1, adv.fibonacci(-1));
    }

    @Test
    void testFibonacciCơBản() {
        // Case n = 0, n = 1 → trả về chính n
        assertEquals(0, adv.fibonacci(0));
        assertEquals(1, adv.fibonacci(1));
    }

    @Test
    void testFibonacciNhỏ() {
        // Case n = 2,3,4,5
        assertEquals(1, adv.fibonacci(2));   // F2 = 1
        assertEquals(2, adv.fibonacci(3));   // F3 = 2
        assertEquals(3, adv.fibonacci(4));   // F4 = 3
        assertEquals(5, adv.fibonacci(5));   // F5 = 5
    }

    @Test
    void testFibonacciLớnHơn() {
        // Thử một giá trị lớn hơn để kiểm tra tính đúng
        assertEquals(55, adv.fibonacci(10)); // F10 = 55
        assertEquals(144, adv.fibonacci(12));// F12 = 144
    }
}
