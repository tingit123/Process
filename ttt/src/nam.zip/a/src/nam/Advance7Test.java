package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.Advance7;

public class Advance7Test {

    Advance7 adv = new Advance7();

    @Test
    void testTinhThuHopLe() {
        // Các ngày hợp lệ, dựa vào số ngày tháng năm tính thứ trong tuần
        assertEquals(1, adv.tinhThu(5, 4, 2020));  // Chủ nhật
        assertEquals(2, adv.tinhThu(6, 4, 2020));  // Thứ Hai
        assertEquals(3, adv.tinhThu(7, 4, 2020));  // Thứ Ba
        assertEquals(4, adv.tinhThu(8, 4, 2020));  // Thứ Tư
        assertEquals(5, adv.tinhThu(9, 4, 2020));  // Thứ Năm
        assertEquals(6, adv.tinhThu(10, 4, 2020)); // Thứ Sáu
        assertEquals(7, adv.tinhThu(11, 4, 2020)); // Thứ Bảy
    }

   

    @Test
    void testTinhThuNgaySinhTrongQuaKhu() {
        // Các ngày trong quá khứ
        assertEquals(1, adv.tinhThu(15, 10, 1995));  // 15/10/1995: Chủ nhật
        assertEquals(2, adv.tinhThu(1, 1, 1900));    // 1/1/1900: Thứ Hai
        assertEquals(3, adv.tinhThu(2, 1, 1900));    // 2/1/1900: Thứ Ba
        assertEquals(4, adv.tinhThu(3, 1, 1900));    // 3/1/1900: Thứ Tư
    }
}
