package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.MaxNumber1;

public class MaxNumber1Test {

    @Test
    void testSoThuNhatLonNhat() {
        MaxNumber1 max = new MaxNumber1();
        max.number1 = 9;
        max.number2 = 5;
        max.number3 = 3;
        int ketqua = max.max3();
        assertEquals(9, ketqua);
    }

    @Test
    void testSoThuHaiLonNhat() {
        MaxNumber1 max = new MaxNumber1();
        max.number1 = 4;
        max.number2 = 8;
        max.number3 = 2;
        int ketqua = max.max3();
        assertEquals(8, ketqua);
    }

    @Test
    void testSoThuBaLonNhat() {
        MaxNumber1 max = new MaxNumber1();
        max.number1 = 1;
        max.number2 = 3;
        max.number3 = 7;
        int ketqua = max.max3();
        assertEquals(7, ketqua);
    }
}
