package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.SolveEquation;

public class SolveEquationTest {

    @Test
    void testMultiRoots() {
        SolveEquation eq = new SolveEquation(0, 0);
        String ketqua = eq.linearEquation();
        assertEquals("Multi roots", ketqua);//nếu a = 0 và b = 0
    }

    @Test
    void testNoRoot() {
        SolveEquation eq = new SolveEquation(0, 5);
        String ketqua = eq.linearEquation();
        assertEquals("No root", ketqua);//nếu a = 0 và b ≠ 0
    }

    @Test
    void testOneRoot() {
        SolveEquation eq = new SolveEquation(3, 6);
        String ketqua = eq.linearEquation();
        assertEquals("One root", ketqua);//nếu a ≠ 0
    }
}
