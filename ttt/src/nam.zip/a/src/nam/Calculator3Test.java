package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.Calculator3;

public class Calculator3Test {

    @Test
    void testPhepNhanBinhThuong() {
        Calculator3 calc = new Calculator3(6, 7);
        int ketqua = calc.mul(); 
        assertEquals(42, ketqua);
    }

    @Test
    void testTranSoNguyenDuong() {
        Calculator3 calc = new Calculator3(Integer.MAX_VALUE, 2);
        int ketqua = calc.mul(); 
        assertTrue(ketqua < 0, "Ket qua bi tran nen thanh so am");
    }

    @Test
    void testTranSoNguyenAm() {
        Calculator3 calc = new Calculator3(Integer.MIN_VALUE, 2);
        int ketqua = calc.mul();
        System.out.println("Kết quả nhân MIN_VALUE * 2 = " + ketqua);

        // Do overflow nên kết quả phải bị sai
        assertTrue(ketqua > 0 || ketqua == 0 || ketqua == Integer.MIN_VALUE, 
            "Kết quả bị tràn nên không hợp lý");
    }
}
