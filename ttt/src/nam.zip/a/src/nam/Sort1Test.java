package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.Sort1;

public class Sort1Test {

    @Test
    void testSoThuNhatLonHon() {
        Sort1 sort = new Sort1();
        sort.number1 = 9;
        sort.number2 = 3;
        sort.sortAsc();
        assertEquals(3, sort.number1);
        assertEquals(9, sort.number2);
    }

    @Test
    void testSoThuNhatNhoHon() {
        Sort1 sort = new Sort1();
        sort.number1 = 2;
        sort.number2 = 5;
        sort.sortAsc();
        assertEquals(2, sort.number1);
        assertEquals(5, sort.number2);
    }
}
