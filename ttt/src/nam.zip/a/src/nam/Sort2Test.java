package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.Sort2;

public class Sort2Test {

    @Test
    void testSoThuNhatLonHon() {
        Sort2 sort = new Sort2();
        sort.setNumber1(8);
        sort.setNumber2(3);
        sort.sortDesc();
        assertEquals(8, sort.getNumber1());
        assertEquals(3, sort.getNumber2());
    }

    @Test
    void testSoThuNhatNhoHon() {
        Sort2 sort = new Sort2();
        sort.setNumber1(2);
        sort.setNumber2(9);
        sort.sortDesc();
        assertEquals(9, sort.getNumber1());
        assertEquals(2, sort.getNumber2());
    }
}
