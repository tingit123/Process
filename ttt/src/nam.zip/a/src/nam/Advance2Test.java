package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.Advance2;

public class Advance2Test {

    Advance2 adv = new Advance2();

    @Test
    void testSoNhieuChuSo() {
        assertEquals(23, adv.sum(5765));
    }

    @Test
    void testSoMotChuSo() {
        assertEquals(9, adv.sum(9));
    }

    @Test
    void testSo0() {
        assertEquals(0, adv.sum(0));
    }

    @Test
    void testSoAm() {
        assertEquals(6, adv.sum(-123)); // |-1| + 2 + 3 = 6
    }
}
