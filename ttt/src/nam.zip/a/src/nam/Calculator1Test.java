package nam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import tran.Calculator1;

public class Calculator1Test {

    @Test
    void testNormalAdd() {
        Calculator1 calc = new Calculator1();
        assertEquals(8, calc.add(3, 5));
    }

    @Test
    void testAddOverflow() {
        Calculator1 calc = new Calculator1();
        int result = calc.add(Integer.MAX_VALUE, 1);
        assertTrue(result < 0, "Dự kiến ​​tràn sẽ gây ra kết quả tích cực ");
    }

    @Test
    void testAddUnderflow() {
        Calculator1 calc = new Calculator1();
        int result = calc.add(Integer.MIN_VALUE, -1);
        assertTrue(result > 0, "dự kiến dưới mức sẽ gây ra kết quả tích cực");
    }
}
